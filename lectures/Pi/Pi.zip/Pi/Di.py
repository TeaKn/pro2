print('Pozdravljeni pri predmetu PRO2!')
