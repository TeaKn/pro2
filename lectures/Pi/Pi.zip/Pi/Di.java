public class Di {
  public static void main(String[] args) {
    System.out.println("Pozdravljeni pri predmetu PRO2!");
  }
}
